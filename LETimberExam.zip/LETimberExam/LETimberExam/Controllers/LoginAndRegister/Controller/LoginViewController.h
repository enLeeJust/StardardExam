//
//  LoginViewController.h
//  SZLTimberTrain
//
//  Created by Apple on 16/9/27.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "SZLBaseVC.h"

@interface LoginViewController : SZLBaseVC

@property(nonatomic,retain)NSMutableData *resultData;
@end
