//
//  LoginInfoDomain.m
//  SZLTimberTrain
//
//  Created by Apple on 16/9/30.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "LoginInfoDomain.h"

@implementation LoginInfoDomain

@end
