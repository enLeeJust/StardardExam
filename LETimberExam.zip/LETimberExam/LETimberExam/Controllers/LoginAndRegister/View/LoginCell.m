//
//  LoginCell.m
//  SZLTimber
//
//  Created by 桂舟 on 16/9/5.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "LoginCell.h"

@implementation LoginCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
