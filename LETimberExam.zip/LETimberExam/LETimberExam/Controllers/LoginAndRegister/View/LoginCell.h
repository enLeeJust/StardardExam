//
//  LoginCell.h
//  SZLTimber
//
//  Created by 桂舟 on 16/9/5.
//  Copyright © 2016年 timber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *usernameLabel;

@end
