//
//  CourseDetailCell.h
//  SZLTimberTrain
//
//  Created by Apple on 16/9/6.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
//static NSString * CourseDetailCellIdentifier = @"CourseDetailCell";
@interface CourseDetailCell : UICollectionViewCell

- (void)configFuncDetailWithIndexPath:(NSIndexPath *)indexPath;

@end
