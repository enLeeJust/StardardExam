//
//  PersonInfoSettingCell.h
//  SZLTimber
//
//  Created by 桂舟 on 16/9/28.
//  Copyright © 2016年 timber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonInfoSettingCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *personItemLabel;
@property (weak, nonatomic) IBOutlet UILabel *personInfoDetailLabel;

@end
