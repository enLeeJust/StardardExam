//
//  MyErrorCell.h
//  SZLTimber
//
//  Created by 桂舟 on 16/9/18.
//  Copyright © 2016年 timber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyErrorCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *myErrorSumLabel;
@property (weak, nonatomic) IBOutlet UILabel *myErrorCourseLabel;

@end
