//
//  AnswerTextFieldsCell.m
//  LETimberExam
//
//  Created by 桂舟 on 16/11/21.
//  Copyright © 2016年 桂舟. All rights reserved.
//

#import "AnswerTextFieldsCell.h"

@implementation AnswerTextFieldsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
