//
//  MyErrorCell.m
//  SZLTimber
//
//  Created by 桂舟 on 16/9/18.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "MyErrorCell.h"

@implementation MyErrorCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
