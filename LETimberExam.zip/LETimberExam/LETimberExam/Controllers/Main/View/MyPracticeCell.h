//
//  MyPracticeCell.h
//  SZLTimber
//
//  Created by 桂舟 on 16/9/14.
//  Copyright © 2016年 timber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPracticeCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *myPrcticeCourseType;
@property (weak, nonatomic) IBOutlet UIImageView *myPracticeIV;

@end
