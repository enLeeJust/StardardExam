//
//  VoteListViewController.h
//  SZLTimberTrain
//
//  Created by Apple on 16/9/20.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import "SZLBaseVC.h"

@interface VoteListViewController : SZLBaseVC

@end
