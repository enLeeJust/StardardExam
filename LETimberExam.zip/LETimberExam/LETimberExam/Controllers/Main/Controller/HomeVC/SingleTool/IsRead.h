//
//  IsRead.h
//  BigShark
//
//  Created by 桂舟 on 16/8/1.
//  Copyright © 2016年 com.timber. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IsRead : NSObject
@property (nonatomic,copy)NSString* UserID;
@property (nonatomic,copy)NSString* ItemId;
@property (nonatomic,copy)NSString* Type;
@end
