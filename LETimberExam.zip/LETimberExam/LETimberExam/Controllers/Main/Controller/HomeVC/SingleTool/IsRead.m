//
//  IsRead.m
//  BigShark
//
//  Created by 桂舟 on 16/8/1.
//  Copyright © 2016年 com.timber. All rights reserved.
//

#import "IsRead.h"

@implementation IsRead
-(NSString*)description
{
    return [NSString stringWithFormat:@"ItemId:%@  Type:%@",self.ItemId,self.Type];
}
@end
