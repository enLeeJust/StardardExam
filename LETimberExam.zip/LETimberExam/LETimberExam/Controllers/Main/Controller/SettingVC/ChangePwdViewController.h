//
//  ChangePwdViewController.h
//  SZLTimber
//
//  Created by 桂舟 on 16/9/29.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "SZLBaseVC.h"

@interface ChangePwdViewController : SZLBaseVC

@property(nonatomic,copy) NSString *changeItemName;
@end
