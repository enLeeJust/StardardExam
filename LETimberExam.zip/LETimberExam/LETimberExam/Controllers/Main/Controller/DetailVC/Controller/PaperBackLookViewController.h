//
//  paperBackLookViewController.h
//  SZLTimber
//
//  Created by 桂舟 on 16/11/2.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "SZLBaseVC.h"

@interface PaperBackLookViewController : SZLBaseVC
@property(nonatomic,copy)NSString *paperUrl;
@end
