//
//  QuesCardCell.m
//  SZLTimber
//
//  Created by 桂舟 on 16/9/20.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "QuesCardCell.h"

@implementation QuesCardCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
