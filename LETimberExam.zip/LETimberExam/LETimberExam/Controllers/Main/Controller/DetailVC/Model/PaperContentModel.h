//
//  paperContentModel.h
//  SZLTimber
//
//  Created by 桂舟 on 16/9/27.
//  Copyright © 2016年 timber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaperContentModel : UIScrollView

@property(nonatomic,strong) UIView *paperQuesTitleView;
@property(nonatomic,strong) UIView *paperQuesBodyView;
@property(nonatomic,strong) UIView *paperQuesAnsAndMarkView;
@end
