//
//  paperContentModel.m
//  SZLTimber
//
//  Created by 桂舟 on 16/9/27.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "PaperContentModel.h"

@implementation PaperContentModel

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
