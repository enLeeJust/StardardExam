//
//  examGradeModel.m
//  SZLTimber
//
//  Created by 桂舟 on 16/10/11.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "ExamGradeModel.h"

@implementation ExamGradeModel

@end
