//
//  NewsOrNoticeModel.m
//  SZLTimber
//
//  Created by 桂舟 on 16/9/28.
//  Copyright © 2016年 timber. All rights reserved.
//

#import "NewsOrNoticeModel.h"

@implementation NewsOrNoticeModel

@end
