//
//  checkOpen.h
//  LETimberExam
//
//  Created by 桂舟 on 16/11/24.
//  Copyright © 2016年 桂舟. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface checkOpen : NSObject
@property(nonatomic,assign) BOOL isOpen;
@end
