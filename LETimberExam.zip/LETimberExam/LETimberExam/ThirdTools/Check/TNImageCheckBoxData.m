//
//  TNImageCheckBoxData.m
//  TNCheckBoxDemo
//
//  Created by Frederik Jacques on 24/04/14.
//  Copyright (c) 2014 Frederik Jacques. All rights reserved.
//

#import "TNImageCheckBoxData.h"

@implementation TNImageCheckBoxData

@end
