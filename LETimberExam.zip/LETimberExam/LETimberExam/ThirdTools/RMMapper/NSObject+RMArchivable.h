//
//  NSObject+TDArchivable.h
//  Roomorama
//
//  Created by DAO XUAN DUNG on 20/11/12.
//
//

#import <Foundation/Foundation.h>

@interface NSObject (RMArchivable)

@end
