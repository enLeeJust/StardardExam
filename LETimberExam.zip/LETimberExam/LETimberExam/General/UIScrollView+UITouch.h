//
//  UIScrollView+UITouch.h
//  SZLTimberTrain
//
//  Created by Apple on 16/9/18.
//  Copyright © 2016年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (UITouch)

@end
